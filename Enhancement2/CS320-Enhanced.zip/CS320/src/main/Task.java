package main;

import java.util.Objects;

/**
 * Represents a task with a unique ID, a name, and a description.
 * Validates input length constraints to ensure data consistency.
 */
public class Task {
    private static final int MAX_ID_LENGTH = 10;
    private static final int MAX_NAME_LENGTH = 20;
    private static final int MAX_DESCRIPTION_LENGTH = 50;

    private final String taskId; // Unique and immutable
    private String name;
    private String description;

    public Task(String taskId, String name, String description) {
        validateId(taskId);
        validateName(name);
        validateDescription(description);
        this.taskId = taskId;
        this.name = name;
        this.description = description;
    }

    // Getters
    public String getTaskId() {
        return taskId;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    // Setters for editable fields
    public void setName(String name) {
        validateName(name);
        this.name = name;
    }

    public void setDescription(String description) {
        validateDescription(description);
        this.description = description;
    }

    // Validation helpers
    private void validateId(String id) {
        if (id == null || id.length() > MAX_ID_LENGTH) {
            throw new IllegalArgumentException("Task ID must not be null and must be at most " + MAX_ID_LENGTH + " characters.");
        }
    }

    private void validateName(String name) {
        if (name == null || name.length() > MAX_NAME_LENGTH) {
            throw new IllegalArgumentException("Name must not be null and must be at most " + MAX_NAME_LENGTH + " characters.");
        }
    }

    private void validateDescription(String description) {
        if (description == null || description.length() > MAX_DESCRIPTION_LENGTH) {
            throw new IllegalArgumentException("Description must not be null and must be at most " + MAX_DESCRIPTION_LENGTH + " characters.");
        }
    }

    @Override
    public String toString() {
        return String.format("Task[%s: %s, %s]", taskId, name, description);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Task)) return false;
        Task task = (Task) o;
        return Objects.equals(taskId, task.taskId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(taskId);
    }
}