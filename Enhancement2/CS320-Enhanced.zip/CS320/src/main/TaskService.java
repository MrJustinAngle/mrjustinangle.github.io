package main;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.Collections;


/**
 * Service to manage Task objects using an in-memory map.
 */
public class TaskService {
    private final Map<String, Task> tasks = new HashMap<>();

    /**
     * Adds a task if it doesn't already exist.
     */
    public void addTask(Task task) {
        if (task == null) {
            throw new IllegalArgumentException("Task cannot be null.");
        }
        String taskId = task.getTaskId();
        if (tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("Task ID already exists: " + taskId);
        }
        tasks.put(taskId, task);
    }

    /**
     * Deletes a task by ID.
     */
    public void deleteTask(String taskId) {
        if (tasks.remove(taskId) == null) {
            throw new IllegalArgumentException("Task ID not found: " + taskId);
        }
    }

    /**
     * Updates the name of a task by ID.
     */
    public void updateTaskName(String taskId, String newName) {
        Task task = getExistingTask(taskId);
        task.setName(newName);
    }

    /**
     * Updates the description of a task by ID.
     */
    public void updateTaskDescription(String taskId, String newDescription) {
        Task task = getExistingTask(taskId);
        task.setDescription(newDescription);
    }

    /**
     * Returns a task by ID, or null if not found.
     */
    public Task getTask(String taskId) {
        return tasks.get(taskId);
    }

    /**
     * Returns an unmodifiable view of all tasks.
     */
    public Map<String, Task> getAllTasks() {
        return Collections.unmodifiableMap(tasks);
    }

    // Private helper
    private Task getExistingTask(String taskId) {
        Task task = tasks.get(taskId);
        if (task == null) {
            throw new IllegalArgumentException("Task ID not found: " + taskId);
        }
        return task;
    }
    
    /**
     * Search function for name or description.
     */
    public List<Task> searchTasks(String query) {
        List<Task> results = new ArrayList<>();
        for (Task task : tasks.values()) {
            if (task.getName().toLowerCase().contains(query.toLowerCase()) ||
                task.getDescription().toLowerCase().contains(query.toLowerCase())) {
                results.add(task);
            }
        }
        return results;
    }
}