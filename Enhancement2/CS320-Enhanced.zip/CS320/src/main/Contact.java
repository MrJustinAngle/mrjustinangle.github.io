package main;

import java.util.Objects;

/**
 * Represents a contact with basic validation rules on its fields.
 */
public class Contact {
    private static final int MAX_ID_LENGTH = 10;
    private static final int MAX_NAME_LENGTH = 10;
    private static final int PHONE_LENGTH = 10;
    private static final int MAX_ADDRESS_LENGTH = 30;

    private String id;
    private String firstName;
    private String lastName;
    private String phone;
    private String address;

    public Contact(String id, String firstName, String lastName, String phone, String address) {
        validateId(id);
        validateName(firstName, "First name");
        validateName(lastName, "Last name");
        validatePhone(phone);
        validateAddress(address);

        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phone = phone;
        this.address = address;
    }

    // Getters
    public String getId() {
        return id;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getPhone() {
        return phone;
    }

    public String getAddress() {
        return address;
    }

    // Optional Setters (to support updates in ContactService)
    public void setFirstName(String firstName) {
        validateName(firstName, "First name");
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        validateName(lastName, "Last name");
        this.lastName = lastName;
    }

    public void setPhone(String phone) {
        validatePhone(phone);
        this.phone = phone;
    }

    public void setAddress(String address) {
        validateAddress(address);
        this.address = address;
    }

    // Validation methods
    private void validateId(String id) {
        if (id == null || id.length() > MAX_ID_LENGTH) {
            throw new IllegalArgumentException("Contact ID must not be null and must be at most " + MAX_ID_LENGTH + " characters.");
        }
    }

    private void validateName(String name, String fieldName) {
        if (name == null || name.length() > MAX_NAME_LENGTH) {
            throw new IllegalArgumentException(fieldName + " must not be null and must be at most " + MAX_NAME_LENGTH + " characters.");
        }
    }

    private void validatePhone(String phone) {
        if (phone == null || phone.length() != PHONE_LENGTH || !phone.matches("\\d{10}")) {
            throw new IllegalArgumentException("Phone number must be exactly " + PHONE_LENGTH + " numeric digits.");
        }
    }

    private void validateAddress(String address) {
        if (address == null || address.length() > MAX_ADDRESS_LENGTH) {
            throw new IllegalArgumentException("Address must not be null and must be at most " + MAX_ADDRESS_LENGTH + " characters.");
        }
    }

    @Override
    public String toString() {
        return String.format("Contact[%s: %s %s, Phone=%s, Address=%s]",
                id, firstName, lastName, phone, address);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Contact)) return false;
        Contact contact = (Contact) o;
        return Objects.equals(id, contact.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}