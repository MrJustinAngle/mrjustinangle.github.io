package main;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Service for managing Appointments in memory.
 */
public class AppointmentService {
    // Use a Map for quick lookup by appointment ID
    private final Map<String, Appointment> appointments;

    public AppointmentService() {
        this.appointments = new HashMap<>();
    }

    /**
     * Adds a new appointment. Throws an exception if ID already exists.
     */
    public void addAppointment(Appointment appointment) {
        String id = ((Appointment) appointment).getAppointmentId();
        if (appointments.containsKey(id)) {
            throw new IllegalArgumentException("Appointment ID already exists.");
        }
        appointments.put(id, appointment);
    }

    /**
     * Deletes an appointment by ID. Throws an exception if ID doesn't exist.
     */
    public void deleteAppointment(String appointmentId) {
        if (appointments.remove(appointmentId) == null) {
            throw new IllegalArgumentException("Appointment ID does not exist.");
        }
    }

    /**
     * Returns an unmodifiable view of all appointments.
     */
    public Map<String, Appointment> getAllAppointments() {
        return Collections.unmodifiableMap(appointments);
    }
    
    /**
     * Returns an appointment by appointmentID.
     */
    public Appointment getAppointment(String appointmentId) {
        return appointments.get(appointmentId);
    }
    
    /**
     * Search function for description or date.
     */
    public List<Appointment> searchAppointments(String query) {
        List<Appointment> results = new ArrayList<>();
        for (Appointment appointment : appointments.values()) {
            if (appointment.getDescription().toLowerCase().contains(query.toLowerCase()) ||
                appointment.getAppointmentDate().toString().contains(query)) {
                results.add(appointment);
            }
        }
        return results;
    }
}
