package main;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import java.util.*;

/**
 * Service to manage Contacts using in-memory Map.
 */
public class ContactService {
    private final Map<String, Contact> contacts;

    public ContactService() {
        this.contacts = new HashMap<>();
    }

    /**
     * Adds a contact to the system.
     */
    public void addContact(Contact contact) {
        if (contacts.containsKey(contact.getId())) {
            throw new IllegalArgumentException("Contact ID already exists.");
        }
        contacts.put(contact.getId(), contact);
    }

    /**
     * Deletes a contact by ID.
     */
    public void deleteContact(String contactId) {
        if (contacts.remove(contactId) == null) {
            throw new IllegalArgumentException("Contact ID not found.");
        }
    }

    /**
     * Updates a specific field of a contact.
     */
    public void updateContactField(String contactId, String fieldName, String newValue) {
        Contact contact = contacts.get(contactId);
        if (contact == null) {
            throw new IllegalArgumentException("Contact ID not found.");
        }

        switch (fieldName.toLowerCase()) {
            case "firstname":
                contact.setFirstName(newValue);
                break;
            case "lastname":
                contact.setLastName(newValue);
                break;
            case "phone":
                contact.setPhone(newValue);
                break;
            case "address":
                contact.setAddress(newValue);
                break;
            default:
                throw new IllegalArgumentException("Invalid field name: " + fieldName);
        }
    }

    /**
     * Retrieves a contact by ID.
     */
    public Contact getContact(String contactId) {
        return contacts.get(contactId);
    }

    /**
     * Returns a list of all contacts.
     */
    public List<Contact> getAllContacts() {
        return Collections.unmodifiableList(new ArrayList<>(contacts.values()));
    }
    
    /**
     * Search function for name, phone or address.
     */
    public List<Contact> searchContacts(String query) {
        List<Contact> results = new ArrayList<>();
        for (Contact contact : contacts.values()) {
            if (contact.getFirstName().toLowerCase().contains(query.toLowerCase()) ||
                contact.getLastName().toLowerCase().contains(query.toLowerCase()) ||
                contact.getPhone().contains(query) ||
                contact.getAddress().toLowerCase().contains(query.toLowerCase())) {
                results.add(contact);
            }
        }
        return results;
    }
}