package test;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import main.Appointment;
import main.AppointmentService;

import java.util.Date;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;


public class AppointmentServiceTest {

    private AppointmentService service;

    @BeforeEach
    void setUp() {
        service = new AppointmentService();
    }

    @Test
    void testAddAndRetrieveAppointment() {
        Appointment a = new Appointment("1", futureDate(), "Check-up");
        service.addAppointment(a);
        assertEquals(a, service.getAppointment("1"));
    }

    @Test
    void testAddDuplicateThrows() {
        Appointment a = new Appointment("1", futureDate(), "Check-up");
        service.addAppointment(a);
        assertThrows(IllegalArgumentException.class, () -> service.addAppointment(a));
    }

    @Test
    void testDeleteAppointment() {
        Appointment a = new Appointment("1", futureDate(), "Check-up");
        service.addAppointment(a);
        service.deleteAppointment("1");
        assertNull(service.getAppointment("1"));
    }

    @Test
    void testDeleteNonexistentAppointmentThrows() {
        assertThrows(IllegalArgumentException.class, () -> service.deleteAppointment("999"));
    }

    private Date futureDate() {
        return new Date(System.currentTimeMillis() + 10000);
    }
    
    @Test
    void testSearchAppointments() {
        AppointmentService service = new AppointmentService();
        Appointment a1 = new Appointment("a1", futureDate(), "Doctor visit at clinic");
        Appointment a2 = new Appointment("a2", futureDate(), "Team meeting");
        Appointment a3 = new Appointment("a3", futureDate(), "Dentist appointment");

        service.addAppointment(a1);
        service.addAppointment(a2);
        service.addAppointment(a3);

        List<Appointment> result1 = service.searchAppointments("doctor");
        assertEquals(1, result1.size());

        List<Appointment> result2 = service.searchAppointments("team");
        assertEquals(1, result2.size());

        List<Appointment> result3 = service.searchAppointments("appointment");
        assertEquals(1, result3.size());

        List<Appointment> result4 = service.searchAppointments("lunch");
        assertTrue(result4.isEmpty());
    }
}