package test;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import main.Task;
import main.TaskService;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

public class TaskServiceTest {

    private TaskService taskService;

    @BeforeEach
    void setUp() {
        taskService = new TaskService();
    }

    @Test
    void testAddAndGetTask() {
        Task task = new Task("1", "Test", "Desc");
        taskService.addTask(task);
        assertEquals("Test", taskService.getTask("1").getName());
    }

    @Test
    void testAddDuplicateTaskThrows() {
        Task task = new Task("1", "Test", "Desc");
        taskService.addTask(task);
        assertThrows(IllegalArgumentException.class, () -> taskService.addTask(task));
    }

    @Test
    void testDeleteTask() {
        Task task = new Task("1", "Test", "Desc");
        taskService.addTask(task);
        taskService.deleteTask("1");
        assertNull(taskService.getTask("1"));
    }

    @Test
    void testDeleteNonexistentTaskThrows() {
        assertThrows(IllegalArgumentException.class, () -> taskService.deleteTask("999"));
    }

    @Test
    void testUpdateName() {
        Task task = new Task("1", "Test", "Desc");
        taskService.addTask(task);
        taskService.updateTaskName("1", "Updated");
        assertEquals("Updated", taskService.getTask("1").getName());
    }

    @Test
    void testUpdateDescription() {
        Task task = new Task("1", "Test", "Desc");
        taskService.addTask(task);
        taskService.updateTaskDescription("1", "Updated Desc");
        assertEquals("Updated Desc", taskService.getTask("1").getDescription());
    }

    @Test
    void testUpdateNonexistentTaskThrows() {
        assertThrows(IllegalArgumentException.class, () -> taskService.updateTaskName("999", "X"));
        assertThrows(IllegalArgumentException.class, () -> taskService.updateTaskDescription("999", "X"));
    }
    
    @Test
    void testSearchTasks() {
        TaskService service = new TaskService();
        Task task1 = new Task("1", "Laundry", "Do laundry at night");
        Task task2 = new Task("2", "Grocery", "Buy groceries from store");
        Task task3 = new Task("3", "Study", "Study math homework");

        service.addTask(task1);
        service.addTask(task2);
        service.addTask(task3);

        List<Task> result1 = service.searchTasks("laundry");
        assertEquals(1, result1.size());
        assertEquals("Laundry", result1.get(0).getName());

        List<Task> result2 = service.searchTasks("groceries");
        assertEquals(1, result2.size());

        List<Task> result3 = service.searchTasks("math");
        assertEquals(1, result3.size());

        List<Task> result4 = service.searchTasks("workout");
        assertTrue(result4.isEmpty());
    }
}