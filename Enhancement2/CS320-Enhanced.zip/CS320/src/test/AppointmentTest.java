package test;

import org.junit.jupiter.api.Test;

import main.Appointment;

import java.util.Date;
import static org.junit.jupiter.api.Assertions.*;


public class AppointmentTest {

    @Test
    void testValidAppointmentCreation() {
        Date futureDate = new Date(System.currentTimeMillis() + 10000);
        Appointment a = new Appointment("123", futureDate, "Dental");
        assertEquals("123", a.getAppointmentId());
        assertEquals(futureDate, a.getAppointmentDate());
        assertEquals("Dental", a.getDescription());
    }

    @Test
    void testInvalidAppointmentId() {
        Date futureDate = new Date(System.currentTimeMillis() + 10000);
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment(null, futureDate, "desc"));
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment("12345678901", futureDate, "desc"));
    }

    @Test
    void testInvalidAppointmentDate() {
        Date pastDate = new Date(System.currentTimeMillis() - 10000);
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment("id1", null, "desc"));
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment("id1", pastDate, "desc"));
    }

    @Test
    void testInvalidDescription() {
        Date futureDate = new Date(System.currentTimeMillis() + 10000);
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment("id1", futureDate, null));
        assertThrows(IllegalArgumentException.class, () ->
            new Appointment("id1", futureDate, "x".repeat(51)));
    }
}