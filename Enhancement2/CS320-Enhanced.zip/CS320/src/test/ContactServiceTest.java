package test;

import org.junit.jupiter.api.Test;

import main.Contact;
import main.ContactService;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;

public class ContactServiceTest {

    private ContactService service;

    @BeforeEach
    void setUp() {
        service = new ContactService();
    }

    @Test
    void testAddAndRetrieve() {
        Contact c = new Contact("1", "John", "Doe", "1234567890", "123 Street");
        service.addContact(c);
        assertEquals(c, service.getContact("1"));
    }

    @Test
    void testAddDuplicateThrows() {
        Contact c = new Contact("1", "John", "Doe", "1234567890", "123 Street");
        service.addContact(c);
        assertThrows(IllegalArgumentException.class, () -> service.addContact(c));
    }

    @Test
    void testDeleteContact() {
        Contact c = new Contact("1", "John", "Doe", "1234567890", "123 Street");
        service.addContact(c);
        service.deleteContact("1");
        assertNull(service.getContact("1"));
    }

    @Test
    void testDeleteNonexistentThrows() {
        assertThrows(IllegalArgumentException.class, () -> service.deleteContact("999"));
    }
    
    @Test
    void testSearchContacts() {
        ContactService service = new ContactService();
        Contact c1 = new Contact("1", "John", "Doe", "1234567890", "123 Main St");
        Contact c2 = new Contact("2", "Jane", "Smith", "0987654321", "456 Elm Ave");
        Contact c3 = new Contact("3", "Alice", "Brown", "5555555555", "789 Oak Blvd");

        service.addContact(c1);
        service.addContact(c2);
        service.addContact(c3);

        List<Contact> result1 = service.searchContacts("Jane");
        assertEquals(1, result1.size());

        List<Contact> result2 = service.searchContacts("Elm");
        assertEquals(1, result2.size());

        List<Contact> result3 = service.searchContacts("5555");
        assertEquals(1, result3.size());

        List<Contact> result4 = service.searchContacts("Zack");
        assertTrue(result4.isEmpty());
    }
}