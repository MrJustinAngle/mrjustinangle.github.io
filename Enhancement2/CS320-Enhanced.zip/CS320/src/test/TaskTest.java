package test;

import org.junit.Test;

import main.Task;

import static org.junit.Assert.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class TaskTest {

    @Test
    public void testValidTaskCreation() {
        Task task = new Task("1", "TestTask", "This is a test.");
        assertEquals("1", task.getTaskId());
        assertEquals("TestTask", task.getName());
        assertEquals("This is a test.", task.getDescription());
    }

    @Test
    public void testSetNameValid() {
        Task task = new Task("1", "OldName", "Description");
        task.setName("NewName");
        assertEquals("NewName", task.getName());
    }

    @Test
    public void testSetNameInvalid() {
        Task task = new Task("1", "Name", "Description");
        assertThrows(IllegalArgumentException.class, () -> task.setName(null));
        assertThrows(IllegalArgumentException.class, () -> task.setName("ThisNameIsWayTooLongToBeAccepted"));
    }

    @Test
    public void testSetDescriptionValid() {
        Task task = new Task("1", "Name", "OldDescription");
        task.setDescription("New Description");
        assertEquals("New Description", task.getDescription());
    }

    @Test
    public void testSetDescriptionInvalid() {
        Task task = new Task("1", "Name", "Description");
        assertThrows(IllegalArgumentException.class, () -> task.setDescription(null));
        assertThrows(IllegalArgumentException.class, () -> task.setDescription("x".repeat(51)));
    }

    @Test
    public void testConstructorValidation() {
        assertThrows(IllegalArgumentException.class, () -> new Task(null, "Name", "Desc"));
        assertThrows(IllegalArgumentException.class, () -> new Task("1", null, "Desc"));
        assertThrows(IllegalArgumentException.class, () -> new Task("1", "Name", null));
        assertThrows(IllegalArgumentException.class, () -> new Task("1", "x".repeat(21), "Desc"));
        assertThrows(IllegalArgumentException.class, () -> new Task("1", "Name", "x".repeat(51)));
    }
}