package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import main.Contact;

public class ContactTest {

    @Test
    void testValidContact() {
        Contact c = new Contact("1", "John", "Doe", "1234567890", "123 Street");
        assertEquals("1", c.getId());
        assertEquals("John", c.getFirstName());
        assertEquals("Doe", c.getLastName());
        assertEquals("1234567890", c.getPhone());
        assertEquals("123 Street", c.getAddress());
    }

    @Test
    void testInvalidId() {
        assertThrows(IllegalArgumentException.class, () -> new Contact(null, "John", "Doe", "1234567890", "123 Street"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("x".repeat(11), "John", "Doe", "1234567890", "123 Street"));
    }

    @Test
    void testInvalidFirstName() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("1", null, "Doe", "1234567890", "123 Street"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("1", "x".repeat(11), "Doe", "1234567890", "123 Street"));
    }

    @Test
    void testInvalidLastName() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("1", "John", null, "1234567890", "123 Street"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("1", "John", "x".repeat(11), "1234567890", "123 Street"));
    }

    @Test
    void testInvalidPhone() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("1", "John", "Doe", null, "123 Street"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("1", "John", "Doe", "123", "123 Street"));
    }

    @Test
    void testInvalidAddress() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("1", "John", "Doe", "1234567890", null));
        assertThrows(IllegalArgumentException.class, () -> new Contact("1", "John", "Doe", "1234567890", "x".repeat(31)));
    }
}