package com.example.project;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.database.Cursor;

/**
 * DBHelper handles all database operations:
 * - User registration & login
 * - Storing and retrieving weight and water data
 */
public class DBHelper extends SQLiteOpenHelper {

    // Constructor: Initializes database with name "WaterTracker.db"
    public DBHelper(Context context) {
        super(context, "WaterTracker.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create users table with username as primary key
        db.execSQL("CREATE TABLE users(username TEXT PRIMARY KEY, password TEXT)");

        // Create data table to store weight and water intake entries
        db.execSQL("CREATE TABLE data(username TEXT, weight REAL, water REAL)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop existing tables if they exist
        db.execSQL("DROP TABLE IF EXISTS users");
        db.execSQL("DROP TABLE IF EXISTS data");

        // Recreate tables
        onCreate(db);
    }

    /**
     * Registers a new user into the 'users' table
     */
    public boolean registerUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("username", username);
        cv.put("password", password);

        // Insert new row and return whether successful
        long result = db.insert("users", null, cv);
        return result != -1;
    }

    /**
     * Checks if a user exists with given credentials
     */
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM users WHERE username=? AND password=?", new String[]{username, password});
        boolean result = c.getCount() > 0;
        c.close();
        return result;
    }

    /**
     * Saves a weight and water entry for the user
     */
    public void saveData(String username, float weight, float water) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("username", username);
        cv.put("weight", weight);
        cv.put("water", water);
        db.insert("data", null, cv);
    }

    /**
     * Gets the most recent water intake value for a user
     */
    public float getWaterIntake(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery(
                "SELECT water FROM data WHERE username=? ORDER BY ROWID DESC LIMIT 1",
                new String[]{username}
        );
        float water = 0;
        if (c.moveToFirst()) {
            water = c.getFloat(0);
        }
        c.close();
        return water;
    }

    /**
     * NEW: Gets all saved entries for a user (for ViewDataActivity)
     */
    public Cursor getData(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery(
                "SELECT weight, water FROM data WHERE username=? ORDER BY ROWID DESC",
                new String[]{username}
        );
    }
}