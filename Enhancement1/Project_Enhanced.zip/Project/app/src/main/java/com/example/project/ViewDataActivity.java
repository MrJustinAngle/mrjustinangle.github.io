package com.example.project;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class ViewDataActivity extends AppCompatActivity {

    ListView dataListView;
    DBHelper db;
    String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_data);

        // Initialize DB and ListView
        dataListView = findViewById(R.id.dataListView);
        db = new DBHelper(this);

        // Get username from intent
        Intent intent = getIntent();
        username = intent.getStringExtra("username");

        // Fetch and display data
        loadUserData();
    }

    // Loading the user data
    private void loadUserData() {
        Cursor cursor = db.getData(username);
        ArrayList<String> dataList = new ArrayList<>();

        if (cursor != null && cursor.getCount() > 0) {
            while (cursor.moveToNext()) {
                float weight = cursor.getFloat(0);
                float water = cursor.getFloat(1);
                String entry = "Weight: " + weight + " kg | Water: " + water + " ml";
                dataList.add(entry);
            }
            cursor.close();

            // Set data to ListView using ArrayAdapter
            ArrayAdapter<String> adapter = new ArrayAdapter<>(
                    this,
                    android.R.layout.simple_list_item_1,
                    dataList
            );
            dataListView.setAdapter(adapter);

        } else {
            Toast.makeText(this, "No data found", Toast.LENGTH_SHORT).show();
        }
    }
}