package com.example.project;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {
    // Declare UI components
    EditText weightInput, waterInput, phoneInput, goalWeightInput, goalWaterInput;
    Button saveBtn, notifyBtn, viewDataBtn, saveGoalBtn;

    // Database helper instance
    DBHelper db;

    // Stores the username passed from login
    String username;

    // SharedPreferences for storing goal values
    SharedPreferences prefs;

    // Default fallback goal if none is set
    final float GOAL = 3000f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home); // Set the layout for this activity

        // Link UI components to layout
        weightInput = findViewById(R.id.weightInput);
        waterInput = findViewById(R.id.waterInput);
        phoneInput = findViewById(R.id.phoneInput);
        saveBtn = findViewById(R.id.saveBtn);
        notifyBtn = findViewById(R.id.notifyBtn);
        viewDataBtn = findViewById(R.id.viewDataBtn);
        goalWeightInput = findViewById(R.id.goalWeightInput);
        goalWaterInput = findViewById(R.id.goalWaterInput);
        saveGoalBtn = findViewById(R.id.saveGoalBtn);

        // Initialize DB helper
        db = new DBHelper(this);

        // Get username from login intent
        username = getIntent().getStringExtra("username");

        // Set up save button: stores weight and water input to DB
        saveBtn.setOnClickListener(v -> {
            float weight = Float.parseFloat(weightInput.getText().toString());
            float water = Float.parseFloat(waterInput.getText().toString());
            db.saveData(username, weight, water);
            Toast.makeText(this, "Data saved", Toast.LENGTH_SHORT).show();
        });

        // Get preferences file for storing goals
        prefs = getSharedPreferences("Goals", MODE_PRIVATE);

        // Preload saved goal values (if available)
        goalWeightInput.setText(prefs.getString("goal_weight_" + username, ""));
        goalWaterInput.setText(prefs.getString("goal_water_" + username, ""));

        // Save goal weight and water values to SharedPreferences
        saveGoalBtn.setOnClickListener(v -> {
            String goalWeight = goalWeightInput.getText().toString();
            String goalWater = goalWaterInput.getText().toString();

            SharedPreferences.Editor editor = prefs.edit();
            editor.putString("goal_weight_" + username, goalWeight);
            editor.putString("goal_water_" + username, goalWater);
            editor.apply();

            Toast.makeText(this, "Goals saved", Toast.LENGTH_SHORT).show();
        });

        // Notify button: checks if user's water intake meets or exceeds goal
        notifyBtn.setOnClickListener(v -> {
            // Fetch latest water intake from database
            float currentWater = db.getWaterIntake(username);

            // Retrieve saved goal from SharedPreferences or use default
            float savedGoalWater;
            try {
                savedGoalWater = Float.parseFloat(prefs.getString("goal_water_" + username, "3000"));
            } catch (NumberFormatException e) {
                savedGoalWater = 3000f; // fallback if parse fails
            }

            // If water intake goal is met or exceeded, send SMS
            if (currentWater >= savedGoalWater) {
                String phone = phoneInput.getText().toString().trim();

                if (phone.isEmpty()) {
                    Toast.makeText(this, "Please enter a phone number", Toast.LENGTH_SHORT).show();
                    return;
                }

                try {
                    SmsManager sms = SmsManager.getDefault();
                    sms.sendTextMessage(phone, null, "Congrats! You've reached your water intake goal!", null, null);
                    Toast.makeText(this, "SMS Sent", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(this, "Failed to send SMS: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    e.printStackTrace();
                }
            } else {
                Toast.makeText(this, "Goal not yet reached", Toast.LENGTH_SHORT).show();
            }
        });

        // Button to navigate to view data activity
        viewDataBtn.setOnClickListener(v -> {
            Intent intent = new Intent(HomeActivity.this, ViewDataActivity.class);
            startActivity(intent);
        });
    }
}