package com.example.project;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.widget.Button;
import android.widget.EditText;
import android.content.Intent;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    // Declare UI components
    EditText username, password;
    Button login, register;

    // Reference to your database helper
    DBHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // Load the login screen layout

        // Link UI elements from XML layout
        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        login = findViewById(R.id.loginBtn);
        register = findViewById(R.id.registerBtn);

        // Initialize the database helper
        db = new DBHelper(this);

        // Handle login button click
        login.setOnClickListener(v -> {
            String user = username.getText().toString();
            String pass = password.getText().toString();

            // Check credentials in database
            if (db.checkUser(user, pass)) {
                // If login successful, go to HomeActivity and pass the username
                Intent intent = new Intent(getApplicationContext(), HomeActivity.class);
                intent.putExtra("username", user); // send username to next activity
                startActivity(intent);
            } else {
                // Show error message if login fails
                Toast.makeText(this, "Invalid credentials", Toast.LENGTH_SHORT).show();
            }
        });

        // Handle register button click — go to registration screen
        register.setOnClickListener(v ->
                startActivity(new Intent(getApplicationContext(), RegisterActivity.class))
        );
    }
}