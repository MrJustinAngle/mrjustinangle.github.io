package com.example.project;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {
    // UI components for user input
    EditText username, password;
    Button register;

    // Database helper instance
    DBHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register); // Load layout for registration screen

        // Connect UI elements from the XML layout to Java variables
        username = findViewById(R.id.regUsername);
        password = findViewById(R.id.regPassword);
        register = findViewById(R.id.regBtn);

        // Initialize the database helper
        db = new DBHelper(this);

        // Set up click listener for the register button
        register.setOnClickListener(v -> {
            // Convert user inputs to strings
            String user = username.getText().toString().trim();
            String pass = password.getText().toString().trim();

            // Basic input validation
            if (user.isEmpty() || pass.isEmpty()) {
                Toast.makeText(this, "Please fill in both fields", Toast.LENGTH_SHORT).show();
                return;
            }

            // Try to register the user
            if (db.registerUser(user, pass)) {
                // Registration successful
                Toast.makeText(this, "Registered successfully", Toast.LENGTH_SHORT).show();
                finish(); // Go back to the login screen
            } else {
                // Registration failed (user already exists)
                Toast.makeText(this, "User already exists", Toast.LENGTH_SHORT).show();
            }
        });
    }
}