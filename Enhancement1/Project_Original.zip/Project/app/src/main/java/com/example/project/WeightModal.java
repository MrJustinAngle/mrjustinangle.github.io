package com.example.project;

public class WeightModal {

    // variables for the wight date and goal weight,
    private String currentWeight;
    private String date;
    private String goalWeight;

    private int id;

    public String getCurrentWeight() { return currentWeight; }

    public void setCurrentWeight(String currentWeight)
    {
        this.currentWeight = currentWeight;
    }

    public String getDate()
    {
        return date;
    }

    public void setDate(String date)
    {
        this.date = date;
    }

    public String getGoalWeight() { return goalWeight; }

    public void setGoalWeight(String goalWeight)
    {
        this.goalWeight = goalWeight;
    }


    public int getId() { return id; }

    public void setId(int id) { this.id = id; }

    // constructor
    public WeightModal(String currentWeight,
                       String date,
                       String goalWeight)
    {
        this.currentWeight = currentWeight;
        this.date = date;
        this.goalWeight = goalWeight;
    }
}
