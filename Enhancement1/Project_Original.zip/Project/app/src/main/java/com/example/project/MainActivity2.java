package com.example.project;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MainActivity2 extends AppCompatActivity {

    // creating variables for our array list,
    // dbhandler, adapter and recycler view.
    private ArrayList<WeightModal> weightModalArrayList;
    private DBHandler dbHandler;
    private WeightRVAdapter weightRVAdapter;
    private RecyclerView weightRV;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        // initializing the variables.
        weightModalArrayList = new ArrayList<>();
        dbHandler = new DBHandler(MainActivity2.this);

        // Getting the weight array from the database
        weightModalArrayList = dbHandler.readWeight();

        // Passing the array list to the adapter class
        weightRVAdapter = new WeightRVAdapter(weightModalArrayList, MainActivity2.this);
        weightRV = findViewById(R.id.idRVdata);

        // This sets the layout manager for the recycler view
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(MainActivity2.this, RecyclerView.VERTICAL, false);
        weightRV.setLayoutManager(linearLayoutManager);

        // This sets the adapter for the recycler view
        weightRV.setAdapter(weightRVAdapter);



    }
}