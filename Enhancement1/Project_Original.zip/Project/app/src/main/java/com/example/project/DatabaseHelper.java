package com.example.project;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.database.Cursor;

public class DatabaseHelper extends SQLiteOpenHelper {

    // The version of database
    private static final int DATABASE_VERSION = 1;

    // The name of database
    private static final String DATABASE_NAME = "logInLog.db";

    // Name of the table
    private static final String TABLE_USERS = "users";
    private static final String TABLE_DATA = "data";

    // The common column name
    private static final String KEY_ID = "id";

    // tables to hold username and password
    private static final String KEY_USERNAME = "username";
    private static final String KEY_PASSWORD = "password";


    // Creating the user table
    private static final String CREATE_TABLE_USERS = "CREATE TABLE "
            + TABLE_USERS + "(" + KEY_ID + " INTEGER PRIMARY KEY," + KEY_USERNAME
            + " TEXT," + KEY_PASSWORD + " TEXT" + ")";



    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Creates the tables
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_USERS);
    }

    // On upgrade drop the older tables
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
           db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);

        // To create new tables
        onCreate(db);
    }

    // The method to add a new user
    public void addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_USERNAME, username);
        values.put(KEY_PASSWORD, password);


        long userId = db.insert(TABLE_USERS, null, values);
        db.close();
    }

    // The method to authenticate a user
    public boolean authenticateUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        String selectQuery = "SELECT  * FROM " + TABLE_USERS + " WHERE "
                + KEY_USERNAME + " = '" + username + "' AND " + KEY_PASSWORD + " = '" + password + "'";

        Cursor c = db.rawQuery(selectQuery, null);

        if (c != null && c.moveToFirst() && c.getCount()>0) {
            //if it matches a user in the database return true
            return true;
        }

        //Otherwise return false
        return false;
    }

}