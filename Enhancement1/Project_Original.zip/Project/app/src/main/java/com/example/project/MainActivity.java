package com.example.project;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.telephony.SmsManager;
import android.content.Intent;

public class MainActivity extends AppCompatActivity {
    EditText nameText, passwordText;
    TextView textGreeting;
    Button buttonLogin, buttonRegister, buttonSendSMS;
    DatabaseHelper db;

    private static final int MY_PERMISSIONS_REQUEST_SEND_SMS = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new DatabaseHelper(this);

        nameText = findViewById(R.id.editTextUsername); // Username text
        passwordText = findViewById(R.id.editTextTextPassword); // Password text
        textGreeting = findViewById(R.id.Welcome); // The text greeting to the app
        buttonLogin = findViewById(R.id.login); // Button to login
        buttonRegister = findViewById(R.id.register); // Button to register if you do not have an account
        buttonSendSMS = findViewById(R.id.buttonSendSMS); // Button to trigger permission for SMS

        // Setting click listeners for the button clicks
        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loginUser();
            }
        });

        buttonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                registerUser();
            }
        });

        buttonSendSMS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendSMSMessage();
            }
        });
    }

    // Setting method for sending SMS messaging
    protected void sendSMSMessage() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, MY_PERMISSIONS_REQUEST_SEND_SMS);
        } else {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage("phoneNo", null, "SMS message", null, null);
        }
    }

    // Either gives permission or does not
    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_SEND_SMS: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    SmsManager smsManager = SmsManager.getDefault();
                    smsManager.sendTextMessage("phoneNo", null, "SMS message", null, null);
                } else {
                    // permission denied
                }
                return;
            }
        }
    }

    // The login method once the login button is clicked
    private void loginUser() {
        String username = nameText.getText().toString();
        String password = passwordText.getText().toString();

        if (db.authenticateUser(username, password)) {
            textGreeting.setText("Hello, " + username);
            Intent intent = new Intent(MainActivity.this, MainActivity3.class);
            startActivity(intent);
        } else {
            textGreeting.setText("Authentication failed.");
        }
    }

    // The register method once the register button is clicked
    private void registerUser() {
        String username = nameText.getText().toString();
        String password = passwordText.getText().toString();

        db.addUser(username, password);
        textGreeting.setText("Registration successful.");
    }
}
